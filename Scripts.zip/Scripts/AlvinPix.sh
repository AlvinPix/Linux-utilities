#!/bin/bash

# Get username
user=$(whoami)

# Directorys
px="PX-games"
ba="Backups"
gi="Github"
bo="Hackthebox"
ne="Networks"
ob="Obsidian"
sc="Scripts"
vi="Services"

# Colors
Black='\033[1;30m'        # Black
Red='\033[1;31m'          # Red
Green='\033[1;32m'        # Green
Yellow='\033[1;33m'       # Yellow
Blue='\033[1;34m'         # Blue
Purple='\033[1;35m'       # Purple
Cyan='\033[1;36m'         # Cyan
White='\033[1;37m'        # White
NC='\033[0m'
blue='\033[0;34m'
white='\033[0;37m'
lred='\033[0;31m'

# Presentation of the script
banner () {
echo -e "${Green}  █████╗ ██╗    ██╗   ██╗██╗███╗   ██╗██████╗ ██╗██╗  ██╗                        "
echo -e "${Green} ██╔══██╗██║    ██║   ██║██║████╗  ██║██╔══██╗██║╚██╗██╔╝                        "
echo -e "${Green} ███████║██║    ██║   ██║██║██╔██╗ ██║██████╔╝██║ ╚███╔╝                         "
echo -e "${Green} ██╔══██║██║    ╚██╗ ██╔╝██║██║╚██╗██║██╔═══╝ ██║ ██╔██╗                         "
echo -e "${Green} ██║  ██║███████╗╚████╔╝ ██║██║ ╚████║██║     ██║██╔╝ ██╗ ${White}Script         "
echo -e "${Green} ╚═╝  ╚═╝╚══════╝ ╚═══╝  ╚═╝╚═╝  ╚═══╝╚═╝     ╚═╝╚═╝  ╚═╝                        "
echo -e "${Green}                     [${White}My settings${Green}]                               "
}

# Script body
body () {
echo ""
	echo -e "${White} Create px paths? y/n"
	echo -ne "${Green} AlvinPix > ${Red}"
	read paths
	echo ""
	if [ $paths = y ]; then
		echo -e "${White} Creating px paths"
		mkdir -p /home/${user}/Escritorio/${px}
		cd /home/${user}/Escritorio/${px}
		echo ""
		echo -e "${White} Creating directory ${Green}(PX-games)"
		echo ""
		echo -e "${White} Creating directory ${Green}(Backups)"
		mkdir -p ${ba}
		echo ""
		echo -e "${White} Creating directory ${Green}(Github)"
		mkdir -p ${gi}
		echo ""
		echo -e "${White} Creating directory ${Green}(Hackthebox)"
		mkdir -p ${bo}
		echo ""
		echo -e "${White} Creating directory ${Green}(Networks)"
                mkdir -p ${ne}
		echo ""
                echo -e "${White} Creating directory ${Green}(Obsidian)"
                mkdir -p ${ob}
		echo ""
                echo -e "${White} Creating directory ${Green}(Scripts)"
                mkdir -p ${sc}
		echo ""
	        echo -e "${White} Creating directory ${Green}(Services)"
                mkdir -p ${vi}
		exit 0
	else
		echo -e "${White} Not creating px paths"
		exit 1
	fi
}


# Call menus the script
echo ""
reset
banner
body


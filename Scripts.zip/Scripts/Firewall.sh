#!/bin/bash

# Colors
Orange='\033[93m'
Black='\033[1;30m'  # NEGRO
Red='\033[1;31m'    # ROJO
Green='\033[1;32m'  # VERDE
Yellow='\033[1;33m' # AMARILLO
Blue='\033[1;34m'   # AZUL
Purple='\033[1;35m' # PURPURA
Cyan='\033[1;36m'   # COLOR CYAN
White='\033[1;37m'  # BLANCO
NC='\033[0m'        # RESET
blue='\033[0;34m'   # OTRO AZUL
white='\033[0;37m'  # OTRO BLANCO
lred='\033[0;31m'   # REINICAR COLOR ORIGINAL


# Presentation of the script
banner () {
echo -e "${Yellow}		     ⠀⠀⠀⠀⠀⠀⢱⣆⠀⠀⠀⠀⠀⠀		"
echo -e "${Yellow}		     ⠀⠀⠀⠀⠀⠀⠈⣿⣷⡀⠀⠀⠀⠀		"
echo -e "${Yellow}		     ⠀⠀⠀⠀⠀⠀⢸⣿⣿⣷⣧⠀⠀⠀		"
echo -e "${Orange}		     ⠀⠀⠀⠀⡀⢠⣿⡟⣿⣿⣿⡇⠀		"
echo -e "${Orange}		     ⠀⠀⠀⠀⣳⣼⣿⡏⢸⣿⣿⣿⢀⠀		"
echo -e "${Orange}		     ⠀⠀⠀⣰⣿⣿⡿⠁⢸⣿⣿⡟⣼⡆		"
echo -e "${Orange}		     ⢰⢀⣾⣿⣿⠟⠀⠀⣾⢿⣿⣿⣿⣿		"
echo -e "${Orange}		     ⢸⣿⣿⣿⡏⠀⠀⠀⠃⠸⣿⣿⣿⡿		"
echo -e "${Orange}		     ⢳⣿⣿⣿⠀⠀⠀⠀⠀⠀⢹⣿⡿⡁		"
echo -e "${Blue}		     ⠀⠹⣿⣿⡄⠀⠀⠀⠀⠀⢠⣿⡞⠁		"
echo -e "${Blue}		     ⠀⠀⠈⠛⢿⣄⠀⠀⠀⣠⠞⠋⠀⠀		"
echo -e "${Blue}   	 	     ⠀⠀⠀⠀⠀⠀⠉			"⠀⠀⠀⠀⠀⠀⠀
echo -e "${Orange} ███████╗██╗██████╗ ███████╗${White}██╗    ██╗ █████╗ ██╗     ██╗	"
echo -e "${Orange} ██╔════╝██║██╔══██╗██╔════╝${White}██║    ██║██╔══██╗██║     ██║	"
echo -e "${Orange} █████╗  ██║██████╔╝█████╗  ${White}██║ █╗ ██║███████║██║     ██║	"
echo -e "${Orange} ██╔══╝  ██║██╔══██╗██╔══╝  ${White}██║███╗██║██╔══██║██║     ██║	"
echo -e "${Orange} ██║     ██║██║  ██║███████╗${White}╚███╔███╔╝██║  ██║███████╗███████╗"
echo -e "${Orange} ╚═╝     ╚═╝╚═╝  ╚═╝╚══════╝${White} ╚══╝╚══╝ ╚═╝  ╚═╝╚══════╝╚══════╝"
}


# The main menu
firewall () {
echo ""
banner
echo ""
echo -e "${White} [${Cyan}1${White}] Exit the script"
}






# Call menus the script
reset
firewall

#!/bin/bash

# Working directory
directory=$(pwd)

# Colors
Black='\033[1;30m'
Red='\033[1;31m'
Green='\033[1;32m'
Yellow='\033[1;33m'
Blue='\033[1;34m'
Purple='\033[1;35m'
Cyan='\033[1;36m'
White='\033[1;37m'
NC='\033[0m'
blue='\033[0;34m'
white='\033[0;37m'
lred='\033[0;31m'

# Check root
if [ $(id -u) -ne 0 ]; then
	echo -e "${Blue} You must be root user to run the script"
	echo -e "${Blue} You must first run the Ghost script"
	exit
fi

# Presentation of the script
banner () {
echo -e "${Blue}       ██████╗ ██╗  ██╗ ██████╗ ███████╗████████╗                                        "
echo -e "${Blue}      ██╔════╝ ██║  ██║██╔═══██╗██╔════╝╚══██╔══╝                                        "
echo -e "${Blue}      ██║  ███╗███████║██║   ██║███████╗   ██║         ${White}By ${Blue}AlvinPix        "
echo -e "${Blue}      ██║   ██║██╔══██║██║   ██║╚════██║   ██║                                           "
echo -e "${Blue}  The ╚██████╔╝██║  ██║╚██████╔╝███████║   ██║   Scanner                                 "
echo -e "${Blue}       ╚═════╝ ╚═╝  ╚═╝ ╚═════╝ ╚══════╝   ╚═╝                                           "
}


# The main menu
ghostscanner () {
clear
echo ""
banner
echo ""
echo -e "${White} [${Yellow}0${White}] Return to main menu"
echo -e "${White} [${Yellow}1${White}] Scan ip address"
echo ""
echo -ne "${White} Ghost > ${Yellow}"
read snc

case $snc in

0)
cd $directory
./Ghost.sh
ghostscanner ;;

1)
echo ""
echo -e "${White} IP address you want to scan"
echo ""
echo -ne "${White} Ghost > ${Yellow}"
read ip
echo ""
echo -e "${White} Scanning ${Blue}(${ip})"
sleep 2
ping -c 1 ${ip} > ping.log
	for i in $(seq 60 70); do
		if test $(grep ttl=${i} ping.log -c) = 1; then
			echo ""
			echo -e "${White} Linux system ${Blue}(TTL=${i})${Yellow} ${ip}"
			sleep 2
                        touch "Ghost_report.md"
                        echo "IP > ${ip}" >> "Ghost_report.md"
                        echo "Linux > TTL=${i}" >> "Ghost_report.md"
			echo "" >> "Ghost_report.md"
fi
done

ping -c 1 ${ip} > ping.log
        for i in $(seq 100 200); do
                if test $(grep ttl=${i} ping.log -c) = 1; then
                        echo ""
                        echo -e "${White} Windows system ${Blue}(TTL=${i})${Yellow} ${ip}"
			sleep 2
			touch "Ghost_report.md"
			echo "IP > ${ip}" >> "Ghost_report.md"
			echo "Windows > TTL=${i}" >> "Ghost_report.md"
			echo "" >> "Ghost_report.md"
fi
done
cd $directory
rm -rf ping.log
echo ""
echo -e "${White} Scanning ${Blue}(${ip})${Yellow} nmap"
sleep 2
nmap -p- --open -sS -sCV --min-rate 5000 -vvv -n -Pn ${ip} >> "Ghost_report.md" 2>/dev/null
echo ""
echo -ne "${White} Press any key to continue..."
read
ghostscanner ;;

* )
echo -e "${Blue} The option is not valid please choose a number"
sleep 1
ghostscanner ;;
esac
}

# Call menu the script
reset
ghostscanner
